package DBPKG;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class db{
	public static Connection getConnection() throws Exception{ 
		Class.forName("oracle.jdbc.OracleDriver"); 
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xe","system","1234"); 
		return con;
	}
	public static PreparedStatement prepare(String sql) throws Exception {
		return getConnection().prepareStatement(sql);
	}
	public static ResultSet exec(String sql) throws Exception {
		try {
			return getConnection().prepareStatement(sql).executeQuery();			
		}catch (Exception e) {
			e.getMessage();
		}
		return null;
	}
}